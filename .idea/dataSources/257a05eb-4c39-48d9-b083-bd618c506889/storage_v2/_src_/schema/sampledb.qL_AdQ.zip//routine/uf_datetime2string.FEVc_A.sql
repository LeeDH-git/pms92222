create
    definer = leedh@localhost function uf_datetime2string(dt_ datetime) returns varchar(10)
BEGIN
    DECLARE ti INTEGER ;
    DECLARE ret_ VARCHAR(10);

    SET ti :=  TIMESTAMPDIFF(MINUTE, dt_, NOW());

    IF ti < 1 THEN SET ret_:='방금';
    ELSEIF ti < 60 THEN SET ret_:= CONCAT(TRUNCATE(ti ,0), '분전');
    ELSEIF ti < 60*24 THEN
        IF ( DATEDIFF(NOW(), dt_)=1) THEN
            SET ret_:= '어제';
        ELSE
            SET ret_:= CONCAT(TRUNCATE(ti/60 ,0), '시간전');
        END IF;
    ELSEIF ti < 60*24*7 THEN SET ret_:= CONCAT(TRUNCATE(ti/60/24 ,0), '일전');
    ELSEIF ti < 60*24*7*4 THEN SET ret_:= CONCAT(TRUNCATE(ti/60/24/7 ,0), '주전');
    ELSEIF (TIMESTAMPDIFF (MONTH, dt_, NOW())=1) THEN SET ret_:= '지난달';
    ELSEIF (TIMESTAMPDIFF (MONTH, dt_, NOW())<13) THEN
        IF ( TIMESTAMPDIFF (YEAR, dt_, NOW())=1) THEN
            SET ret_:= '작년';
        ELSE
            SET ret_:= CONCAT(TRUNCATE(TIMESTAMPDIFF (MONTH, dt_, NOW()) ,0), '달전');
        END IF;
    ELSE SET ret_:= CONCAT(TIMESTAMPDIFF (YEAR, dt_, NOW()), '년전');
    END IF;

    RETURN ret_;
END;

